import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  gas = null;
  etan = null;
  resposta = '';
  mensagem = "";

  img_combustiveis = [
    'etanol.png',
    'gasolina_x_alcool.jpg',
    'gasolina.png',
    'tanto_faz.jpg'
  ]

  imagem = 'gasolina_x_alcool.jpg'

constructor() {}

calcular(indice: number): void{
  let r = this.etan / this.gas
  this.resposta = r.toFixed(2).toString();

  if (r > 0.7){
    this.mensagem = "A gasolina é mais vantajosa!";
    this.imagem = this.img_combustiveis[2]
  } else if (r < 0.7){
    this.mensagem = "O etanol é mais vantajoso!";
    this.imagem = this.img_combustiveis[0]
  } else {
    this.mensagem = "Tanto faz!";
    this.imagem = this.img_combustiveis[3]
  }
}

  }
