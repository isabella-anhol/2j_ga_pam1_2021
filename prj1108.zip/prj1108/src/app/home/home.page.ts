import { SourceMapGenerator } from '@angular/compiler/src/output/source_map';
import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  display = '';
  memoria = '';
  operacao = '';
  auxiliar = '';
  usouPonto = false;
  estaVazio = true;

  constructor() {}

  clicar(numero: string){
    this.display= this.display + numero;

    this.verificarDisplayVazio();
  }

  verificarDisplayVazio(){
    if(this.display.length !== 0){
      this.estaVazio = false;
    }
  }

  usarPonto(){
    if(this.display === ''){
      this.display = this.display + '0';
    }

    this.display = this.display + '.';
    this.usouPonto = true;
  }

  verificarCalculo(operacao: string){
    this.operacao = operacao;
    this.memoria = this.display;
    this.display = '';
  }

  efetuarCaculo(){
    console.log("Memória: " + this.memoria)
    console.log("Display: " + this.display)
    console.log("Auxiliar: " + this.auxiliar)

    switch(this.operacao){
      case '+':
        this.somar();
      break;
      case '-':
        this.subtrair();
      break;
      case '*':
        this.multiplicar();
      break;
      case '/':
        this.dividir();
      break;
    }
  }

  somar(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== '' && this.auxiliar === ''){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }
    else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 + n2;

    this.display = resp.toString();

    this.auxiliar = n2.toString();
  }

  subtrair(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== '' && this.auxiliar === ''){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }
    else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 - n2;

    this.display = resp.toString();

    this.auxiliar = n2.toString();
  }

  multiplicar(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== '' && this.auxiliar === ''){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }
    else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 * n2;

    this.display = resp.toString();

    this.auxiliar = n2.toString();
  }

  dividir(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== '' && this.auxiliar === ''){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }
    else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 / n2;

    this.display = resp.toString();

    this.auxiliar = n2.toString();
  }

  limpar(){
    this.display = '';
    this.memoria = '';
    this.operacao = '';
    this.auxiliar = '';
    this.usouPonto = false;
    this.estaVazio = true;
  }
}
